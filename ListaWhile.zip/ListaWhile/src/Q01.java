import java.util.Scanner;

public class Q01 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		double salarJoao, salarCarlos;
		int mes = 0;
		
		System.out.print("Informe o sal�rio de Carlos: ");
		salarCarlos = sc.nextInt();
		
		salarJoao = salarCarlos / 3;
		
		while(salarJoao < salarCarlos) {
			salarCarlos += salarCarlos * 0.02;
			salarJoao += salarJoao * 0.05;
			mes++;
		}
		System.out.println("Foram precisos "+mes+" meses para o sal�rio de Jo�o ultrapassar o de Carlos");
		sc.close();
	}

}
