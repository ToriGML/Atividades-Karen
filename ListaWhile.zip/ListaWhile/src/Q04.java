import java.util.Scanner;

public class Q04 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		double valor, somaTotal = 0;
		int qtd = 0;
		
		System.out.println("Informe seu sal�rio: ");
		double salar = sc.nextDouble();
		
		while(salar != 0) {
		
		System.out.println("Escolha que tipo de consumidor voc� �: "
				+ "\n1 - Residencial"
				+ "\n2 - Comercial"
				+ "\n3 = Industrial"
				+ "\n--> ");
		int tipo = sc.nextInt();
		
		double quilowatts = salar/8;
		
		switch (tipo) {
		case 1:
			valor = quilowatts + (quilowatts * 0.05);
			if(valor >= 500 && valor <= 1000) {
				qtd++;
			}
			somaTotal += valor;
			break;
		case 2:
			valor = quilowatts + (quilowatts * 0.05);
			if(valor >= 500 && valor <= 1000) {
				qtd++;
			}
			somaTotal += valor;
			break;
		case 3:
			valor = quilowatts + (quilowatts * 0.05);
			if(valor >= 500 && valor <= 1000) {
				qtd++;
			}
			somaTotal += valor;
			break;
		default:
			System.out.println("Consumidor inv�lido!");
		}
		
		System.out.println("Informe seu sal�rio: ");
		salar = sc.nextDouble();
		}
		System.out.println("Faturamento geral: R$"+somaTotal
				+ "\nQuantidade de consumidores que pagem entre R$500 � R$1000: "+ qtd);
		sc.close();
	}

}
