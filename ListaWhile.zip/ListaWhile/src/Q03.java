import java.util.Scanner;

public class Q03 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		System.out.println("Informe um n�mero: ");
		int numero = sc.nextInt();
		
		double soma = 0, media = 0, percentage, maiorNum = 0, menorNum = 9999999, pares = 0, impares = 0, cont = 0, contPares = 0;
		
		while(numero != 30000) {
			soma += numero;
			if(numero % 2 == 0) {
				pares += numero;
				contPares++;
			}else {
				impares++;
			}
			if(numero > maiorNum) {
				maiorNum = numero; 
			}
			if(numero < menorNum) {
				menorNum = numero; 
			}
			cont++;
			
			System.out.println("\nInforme um n�mero: ");
			numero = sc.nextInt();
		}
			media = pares / contPares;
			percentage = (impares / cont) * 100;
			System.out.println("Soma: "+soma
					+ "\nQuantidade: "+cont
					+ "\nMaior n�mero: "+maiorNum
					+ "\nMenor n�mero: "+menorNum
					+ "\nM�dia pares: "+media
					+ "\nPorcentagem impares: "+percentage+"%");
			sc.close();
	}

}
