import java.util.Scanner;

public class Q02 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		System.out.println("Informe um n�mero: ");
		int numero = sc.nextInt();
		
		while(numero != 0) {
			
			double raiz = Math.sqrt(numero);
			double quadrado = Math.pow(numero, 2);
			double cubo = Math.pow(numero, 3);
			
			System.out.println("N�mero informado: "+numero
					+ "\nRa�z: "+raiz
					+ "\nQuadrado: "+quadrado
					+ "\nCubo: "+cubo);
			
			System.out.println("\nInforme um n�mero: ");
			numero = sc.nextInt();
		}
		System.out.println("Cabo!");
		sc.close();
	}

}
