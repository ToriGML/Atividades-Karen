package Att;

import java.util.Scanner;

public class QuestaoN {

	public static void main(String[] args) {

		int kg, grama, gramas, cincodays, kg2;

		Scanner sc = new Scanner(System.in);

		System.out.print("Informe quantos quilos tem o sacao de ra��o: ");
		kg = sc.nextInt();
		System.out.print("Informe quantas gramas s�o fornecidas aos gatos: ");
		gramas = sc.nextInt();

		grama = kg * 1000;

		cincodays = grama - ((gramas * 2) * 5);

		kg2 = cincodays / 1000;

		sc.close();
		
		System.out.println("Sobrar� apenas " + kg2 + " quilos no saco depois de cinco dias");
	}

}
