package Att;

import java.util.Scanner;

public class QuestaoE {

	public static void main(String[] args) {

		double salar, comis, salarfim;

		Scanner sc = new Scanner(System.in);

		System.out.print("Informe seu sal�rio: ");
		salar = sc.nextDouble();
		System.out.print("Informe seu valor de venda: ");
		comis = sc.nextDouble();

		salarfim = salar + (comis * 0.04);
		
		sc.close();

		System.out.println("Esse � seu sal�rio final: R$" + salarfim);
	}

}
