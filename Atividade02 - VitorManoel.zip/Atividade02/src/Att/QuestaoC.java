package Att;

import java.util.Scanner;

public class QuestaoC {

	public static void main(String[] args) {

		int a, b, div;

		Scanner sc = new Scanner(System.in);

		System.out.print("Informe um n�mero: (N�o pode ser zero) ");
		a = sc.nextInt();
		System.out.print("Informe outro n�mero: ");
		b = sc.nextInt();

		div = a / b;

		sc.close();

		System.out.println("Essa � a divis�o dos dois n�meros: " + div);

	}

}