package Att;

import java.util.Scanner;

public class QuestaoK {

	public static void main(String[] args) {

		int min, hr, seg, mintot, hrmin;

		Scanner sc = new Scanner(System.in);

		System.out.print("Informe quantas horas foram: ");
		hr = sc.nextInt();
		System.out.print("Informe quantos minutos foram: ");
		min = sc.nextInt();

		hrmin = hr * 60;
		mintot = min + hrmin;
		seg = mintot * 60;
		
		sc.close();

		System.out.println(
				"Horas informadas em minutos: " + hrmin + "\nMinutos totais: " + mintot + "\nSegundos totais: " + seg);

	}

}
