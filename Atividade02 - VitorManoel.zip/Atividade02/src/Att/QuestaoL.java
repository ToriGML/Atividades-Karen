package Att;

import java.util.Scanner;

public class QuestaoL {

	public static void main(String[] args) {

		double custo, convite, qtdconvite;

		Scanner sc = new Scanner(System.in);

		System.out.print("Informe o custo da pe�a teatral: ");
		custo = sc.nextDouble();
		System.out.print("Informe o pre�o do convite: ");
		convite = sc.nextDouble();

		qtdconvite = custo / convite;

		sc.close();

		System.out.print("Precisam ser vendidos no m�nimo " + qtdconvite + " convites");

	}

}
