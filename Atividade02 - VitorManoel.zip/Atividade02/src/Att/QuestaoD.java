package Att;

import java.util.Scanner;

public class QuestaoD {

	public static void main(String[] args) {

		double preco, desconto;

		Scanner sc = new Scanner(System.in);

		System.out.print("Informe o pre�o do produto: ");
		preco = sc.nextDouble();

		desconto = preco - (preco * 0.1);

		sc.close();
		
		System.out.println("Esse � o novo pre�o: R$" + desconto);

	}

}
