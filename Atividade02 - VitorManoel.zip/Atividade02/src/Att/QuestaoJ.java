package Att;

import java.util.Scanner;

public class QuestaoJ {

	public static void main(String[] args) {
		
		double real, dolar, euro, libra;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Informe quanto voc� tem: ");
		real = sc.nextDouble();
		
		dolar = real / 4.97;
		euro = real / 5.23;
		libra = real / 6.25;
		
		sc.close();
		
		System.out.println("Isso � o que voc� teria em d�lares: "+dolar+"\nIsso � o que voc� teria em euros: "+euro+"\nIsso � o que voc� teria em Libras Esterlinas: "+libra);

	}

}
