package Att;

import java.util.Scanner;

public class QuestaoG {

	public static void main(String[] args) {
		
		int num, vezes, contador = 1;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Informe um n�mero: ");
		num = sc.nextInt();
		
		while(contador <= 10) {
			vezes = num * contador;
			System.out.print(num +" * "+contador+" = "+vezes+"\n");
			contador++;
		}
		
		sc.close();
		


	}

}
