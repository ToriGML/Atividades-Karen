package Att;

import java.util.Scanner;

public class QuestaoM {

	public static void main(String[] args) {

		int kw;
		double salarmin, valortot, valorkw, desconto;

		Scanner sc = new Scanner(System.in);

		System.out.print("Informe o valor do sal�rio m�nimo: ");
		salarmin = sc.nextDouble();
		System.out.print("Informe quantos Quilowatts foram consum�dos: ");
		kw = sc.nextInt();

		valorkw = salarmin / 5;
		valortot = kw * valorkw;
		desconto = valortot - (valortot * 0.15);

		sc.close();

		System.out.println("Valor de cada Quilowatts: R$" + valorkw + "\nValor a ser pagado pela resid�ncia: R$"
				+ valortot + "\nValor com desconto: R$" + desconto);

	}

}
