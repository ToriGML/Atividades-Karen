package Att;

import java.util.Scanner;

public class QuestaoA {

	public static void main(String[] args) {

		int a, b, sub;

		Scanner sc = new Scanner(System.in);

		System.out.print("Informe um n�mero: ");
		a = sc.nextInt();
		System.out.print("Informe outro n�mero: ");
		b = sc.nextInt();

		sub = a - b;

		sc.close();

		System.out.println("Essa � a subtra��o dos dois n�meros: " + sub);

	}

}
