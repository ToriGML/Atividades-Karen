package Att;

import java.util.Scanner;

public class QuestaoI {

	public static void main(String[] args) {

		double salarmin, qtdhrs, vlrhrs, qtdhrs_ex, vlrhrs_ex, salar, extra, liquid;

		Scanner sc = new Scanner(System.in);

		System.out.print("Informe o valor do sal�rio m�nimo: ");
		salarmin = sc.nextDouble();
		System.out.print("Informe a quantidade de horas trbalhadas: ");
		qtdhrs = sc.nextInt();
		System.out.print("Informe a quantidade de horas extras trbalhadas: ");
		qtdhrs_ex = sc.nextInt();

		vlrhrs = salarmin / 8;
		vlrhrs_ex = salarmin / 4;

		salar = qtdhrs * vlrhrs;
		extra = qtdhrs_ex * vlrhrs_ex;

		liquid = salar + extra;
		
		sc.close();

		System.out.println("Esse � seu sal�rio: " + liquid);
	}

}
