package Att;

import java.util.Scanner;

public class QuestaoF {

	public static void main(String[] args) {
		
		double salar, salarmin, qtd;

		Scanner sc = new Scanner(System.in);
		
		System.out.print("Informe seu sal�rio: ");
		salar = sc.nextDouble();
		System.out.print("Informe quanto est� o sal�rio m�nimo: ");
		salarmin = sc.nextDouble();
		
		qtd = salar / salarmin;
		
		sc.close();
		
		System.out.println("Voc� recebe "+qtd+" sal�rios m�nimos");
	}

}
