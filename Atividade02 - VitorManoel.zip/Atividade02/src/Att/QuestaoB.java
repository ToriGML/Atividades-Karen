package Att;

import java.util.Scanner;

public class QuestaoB {

	public static void main(String[] args) {

		int a, b, mult;

		Scanner sc = new Scanner(System.in);

		System.out.print("Informe um n�mero: ");
		a = sc.nextInt();
		System.out.print("Informe outro n�mero: ");
		b = sc.nextInt();

		mult = a * b;

		sc.close();

		System.out.println("Essa � a multiplica��o dos dois n�meros: " + mult);

	}

}