package Att;

import java.util.Scanner;

public class QuestaoH {

	public static void main(String[] args) {

		double salar, div1, div2, valor1, valor2, tot;

		Scanner sc = new Scanner(System.in);

		System.out.print("Informe o sal�rio de Jo�o:");
		salar = sc.nextDouble();
		System.out.print("Informe o valor da primeira d�vida: ");
		div1 = sc.nextDouble();
		System.out.print("Informe o valor da segunda d�vida: ");
		div2 = sc.nextDouble();

		valor1 = div1 + (div1 * 0.02);
		valor2 = div2 + (div2 * 0.02);
		tot = salar - (valor1 + valor2);
		
		sc.close();
		
		System.out.println("O que sobrou do seu sal�rio: " + tot);

	}

}
