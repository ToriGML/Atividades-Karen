import java.util.Scanner;

public class Q03 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		double resA, resB;
		System.out.println("Informe quantos livros ir� querer: ");
		int quantidade = sc.nextInt();
		
		resA = (quantidade * 0.25) + 7.5;
		resB = (quantidade * 0.5) + 2.5;
		
		if(resA > resB) {
			System.out.println("A melhor op��o de pagamento � a B: R$"+resB);
		}else if(resA < resB){
			System.out.println("A melhor op��o de pagamento � a A: R$"+resA);
		}else {
			System.out.println("Op��es com mesmo pre�o: \nA - R$"+resA+"\nB - R$"+resB);
		}
		sc.close();
	}

}
