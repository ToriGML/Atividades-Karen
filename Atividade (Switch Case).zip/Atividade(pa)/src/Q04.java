import java.util.Scanner;

public class Q04 {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		double desconto, preco, parcela;
		System.out.println("Informe o valor total da compra: ");
		double valor = sc.nextDouble();
		System.out.println("Informe a forma de pagamento:"
				+ "\n1 - Pagamento � vista (15% de desconto)"
				+ "\n2 - Pagamento com cheque pr�-datado para 30 dias (10% de desconto)"
				+ "\n3 - Pagamento parcelado em 6 vezes (Sem desconto)"
				+ "\n4 - Pagamento parcelado em 12 vezes (8% de acr�scimo)"
				+ "\n--> ");
		int opcao = sc.nextInt();
		
		switch (opcao) {
		case 1:
			desconto = valor * 0.15;
			preco = valor - desconto;
			System.out.println("O valor final ficou igual �: R$"+preco);
			break;
		case 2:
			desconto = valor * 0.1;
			preco = valor - desconto;
			System.out.println("O valor final ficou igual �: R$"+preco);
			break;
		case 3:
			parcela = valor/6;
			System.out.println("O valor final ficou igual �: R$"+valor+"\nValor das parcelas: "+parcela);
			break;
		case 4:
			valor += valor * 0.08;
			parcela = valor/12;
			System.out.println("O valor final ficou igual �: R$"+valor+"\nValor das parcelas: "+parcela);
			break;
		}
		sc.close();
	}
}
