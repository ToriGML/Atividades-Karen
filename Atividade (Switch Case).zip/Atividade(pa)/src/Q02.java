import java.util.Scanner;

public class Q02 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		double gramas,imposto = 0, preco = 0, valor, valorTot;
		System.out.println("Informe o c�digo do produto comprado: ");
		int cod = sc.nextInt();
		System.out.println("Informe o peso do produto: ");
		double peso = sc.nextDouble();
		System.out.println("Informe o c�digo do seu pa�s: ");
		int codPais = sc.nextInt();
		                              
		switch(codPais) {
		case 1:
			imposto = 0;
			break;
		case 2:
			imposto = 0.15;
			break;
		case 3:
			imposto = 0.25;
			break;
		default:
			System.out.println("C�digo inv�lido!!");
		}
		
		switch(cod) {
		case 1:
			gramas = peso * 100;
			preco = gramas * 10;
			break;
		case 2:
			gramas = peso * 100;
			preco = gramas * 10;
			break;
		case 3:
			gramas = peso * 100;
			preco = gramas * 10;
			break;
		case 4:
			gramas = peso * 100;
			preco = gramas * 10;
			break;
		case 5:
			gramas = peso * 100;
			preco = gramas * 25;
			break;
		case 6:
			gramas = peso * 100;
			preco = gramas * 25;
			break;
		case 7:
			gramas = peso * 100;
			preco = gramas * 25;
			break;
		case 8:
			gramas = peso * 100;
			preco = gramas * 35;
			break;
		case 9:
			gramas = peso * 100;
			preco = gramas * 35;
			break;
		case 10:
			gramas = peso * 100;
			preco = gramas * 35;
			break;
		default:
			System.out.println("C�digo inv�lido!!");
		}
		valor = preco * imposto;
		valorTot = preco + valor;
		System.out.println("Peso do produto: "+peso
				+ "\nPre�o total: "+preco
				+ "\nValor do imposto: "+valor
				+ "\nValor total: "+ valorTot);
		sc.close();
	}

}
