import java.util.Scanner;

public class Q01 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int cod;
		double  salar, aumento, valor;
		System.out.println("Informe o seu sal�rio atual: ");
		salar = sc.nextDouble();
		System.out.println("Informe o c�digo do seu cargo: "
				+ "\n1 - Escritur�rio"
				+ "\n2 - Secret�rio"
				+ "\n3 - Caixa"
				+ "\n4 - Gerente"
				+ "\n5 - Diretor"
				+ "\n--> ");
		cod = sc.nextInt();
		
		switch(cod) {
		case 1:
			valor = salar * 0.5;
			aumento = salar + valor;
			System.out.println("Seu sal�rio anterior: "+salar
					+ "\nSeu cargo: Escritur�rio"
					+ "\nO valor do aumento: "+valor
					+ "\nSeu novo sal�rio: "+aumento);
			break;
		case 2:
			valor = salar * 0.35;
			aumento = salar + valor;
			System.out.println("Seu sal�rio anterior: "+salar
					+ "\nSeu cargo: Secret�rio"
					+ "\nO valor do aumento: "+valor
					+ "\nSeu novo sal�rio: "+aumento);
			break;
		case 3:
			valor = salar * 0.2;
			aumento = salar + valor;
			System.out.println("Seu sal�rio anterior: "+salar
					+ "\nSeu cargo: Caixa"
					+ "\nO valor do aumento: "+valor
					+ "\nSeu novo sal�rio: "+aumento);
			break;
		case 4:
			valor = salar * 0.1;
			aumento = salar + valor;
			System.out.println("Seu sal�rio anterior: "+salar
					+ "\nSeu cargo: Gerente"
					+ "\nO valor do aumento: "+valor
					+ "\nSeu novo sal�rio: "+aumento);
			break;
		case 5:
			valor = salar * 0.5;
			aumento = salar + valor;
			System.out.println("Seu sal�rio: "+salar
					+ "\nSeu cargo: Diretor"
					+ "\nN�o tem aumento");
			break;
		default:
			System.out.println("C�digo inv�lido!!");
			break;
		}
		sc.close();
	}

}
