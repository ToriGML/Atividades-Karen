import java.util.Scanner;

public class Q02 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int cont = 0, menorIndiceCidade = 0, maiorIndiceCidade = 0, somaVeiculos = 0, somaAcidentes = 0;
		double mediaVeiculos, mediaAcidentes, indice, menorIndice = 9999999, maiorIndice = 0;
		
		do{
		System.out.println("Informe o c�digo da cidade: ");
		int codigo = sc.nextInt();
		System.out.println("Informe o n�mero de ve�culos: ");
		int numVeiculos = sc.nextInt();
		System.out.println("Informe o n�mero de acidentes com v�timas: ");
		int numAcidentes = sc.nextInt();
		
		indice = (numAcidentes / numVeiculos) * 100;
		if(numVeiculos < 2000) {
			somaAcidentes += numAcidentes;
		}
		if(indice < menorIndice) {
			menorIndice = indice;
			menorIndiceCidade = codigo;
		}
		if(indice > maiorIndice) {
			maiorIndice = indice;
			maiorIndiceCidade = codigo;
		}
		somaVeiculos += numVeiculos;
		cont++;
		}while(cont < 5);
		mediaVeiculos = somaVeiculos / 5;
		mediaAcidentes = somaAcidentes / 5;
		System.out.println("Maior �ndice: "+maiorIndice+"%"
				+ "\nCidade com maior �ndice: "+maiorIndiceCidade
				+ "\nMenor �ndice: "+menorIndice+"%"
				+ "\nCidade com o menor �ndice: "+menorIndiceCidade
				+ "\nM�dia de ve�culos: "+mediaVeiculos
				+ "\nM�dia de acidentes de tr�nsito nas cidades com menos de 2.000 ve�culos: "+mediaAcidentes);
		sc.close();
	}

}
