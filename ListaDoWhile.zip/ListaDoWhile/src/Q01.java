import java.util.Scanner;

public class Q01 {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int num;
		
		do {
			System.out.println("Informe um n�mero: ");
			num = sc.nextInt();
			
			if(num % num == 0 && num % 1 == 0 && num % 2 != 0) {
				System.out.println("N�o � primo!");	
			}else{
				System.out.println("primo!");
			}
		}while(num != 0);
		
		sc.close();
	}
}
