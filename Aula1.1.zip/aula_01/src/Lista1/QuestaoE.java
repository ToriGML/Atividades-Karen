package Lista1;

import java.util.Scanner;

public class QuestaoE {

	public static void main(String[] args) {
		
		int num;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Informe um n�mero: ");
		num = sc.nextInt();
		
		sc.close();
		
		System.out.println("O n�mero digitado foi: "+num);

	}

}
