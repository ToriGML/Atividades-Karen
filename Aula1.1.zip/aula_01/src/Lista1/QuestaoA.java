package Lista1;

public class QuestaoA {

	public static void main(String[] args) {
		
		System.out.println("� preciso fazer todos os algoritimos para aprender!!");

	}

}
