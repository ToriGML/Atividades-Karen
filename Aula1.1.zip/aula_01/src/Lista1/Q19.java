package Lista1;

public class Q19 {

	public static void main(String[] args) {

		double media1, media2, soma, media3;

		media1 = (8 + 9 + 7) / 3;
		media2 = (4 + 5 + 6) / 3;
		soma = media1 + media2;
		media3 = soma / 2;
		System.out.println("Primeira m�dia: "+media1+"\nSegunda m�dia: "+media2+"\nSoma das m�dias: "+soma+"\nM�dia das m�dias: "+media3);

	}

}

