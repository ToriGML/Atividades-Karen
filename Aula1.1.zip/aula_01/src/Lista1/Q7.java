package Lista1;

public class Q7 {

	public static void main(String[] args) {
		
		String y ="Estou aprendendo java";
		
		System.out.println(y);
		
	}
}
