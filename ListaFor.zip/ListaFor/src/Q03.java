import java.util.Scanner;

public class Q03 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		double salar = 0, salarTotal = 0, mediaPecasM, mediaPecasF, numeroMaiorSalar = 0, maiorSalar = 0;
		int qtd, qtdTotal = 0, somaPecasM = 0, somaPecasF = 0, qtdM = 0, qtdF = 0;
		String Text="";
		
		for(int i = 0; i < 15;i++) {
		System.out.println("Informe o n�mero do funcion�rio/a: ");
		int numero = sc.nextInt();
		System.out.println("N�mero de pe�as fabricadas por esse do funcion�rio/a no m�s: ");
		int numPecas = sc.nextInt();
		System.out.println("informe o g�nero do funcion�rio/a");
		char genero = sc.next().charAt(0);
		if(numPecas <= 30) {
			salar = 1200;
		}
		if(numPecas > 30 && numPecas <= 50) {
			qtd = numPecas - 30;
			salar = 1200 + (qtd *(1200 * 0.03));
		}
		if(numPecas > 50) {
			qtd = numPecas - 30;
			salar = 1200 + (qtd *(1200 * 0.05));
		}
		if(genero == 'M' || genero == 'm') {
			somaPecasM += numPecas;
			qtdM++;
		}else if(genero == 'F' || genero == 'f') {
			somaPecasF += numPecas;
			qtdF++;
		}else {
			System.out.println("G�nero inv�lido!");
		}
		if(salar > maiorSalar) {
			maiorSalar = salar;
			numeroMaiorSalar = numero;
		}
		qtdTotal += numPecas;
		salarTotal += salar;
		Text += "Funcion�rio n�"+numero+" - R$"+salar+"\n";
		}
		mediaPecasM = somaPecasM / qtdM;
		mediaPecasF = somaPecasF / qtdF;
		System.out.println(Text+"Total da folha de pagamento: "+ salarTotal
				+ "\nN�mero total de pe�as produzidas: "+qtdTotal
				+ "\nM�dia de pe�as fabricadas por homens: "+mediaPecasM
				+ "\nM�dia de pe�as fabricadas por mulheres: "+mediaPecasF
				+ "\nN�mero do funcion�rio com o maior sal�rio: "+numeroMaiorSalar);
		sc.close();
	}

}
