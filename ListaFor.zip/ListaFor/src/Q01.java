import java.util.Scanner;

public class Q01 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Informe um n�mero: ");
		int numero = sc.nextInt();

		for(int i = 1; i <= 10; i++) {
			int vezes = numero * i;
			System.out.println(numero+" * "+i+" = "+vezes);
		}
		sc.close();
	}

}
