import java.util.Scanner;

public class Q02 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int qtdMenor18 = 0, somaIdade = 0;
		double somaAltura = 0, porcentagePeso, somaPeso = 0, mediaIdade, mediaAltura;
		
		for(int i = 1; i <= 2;i++) {
			for(int j = 1; j <= 11; j++) {
				System.out.print("Informe a idade do "+j+"� jogador do "+i+"� time: ");
				int idade = sc.nextInt();
				System.out.print("Informe a altura do "+j+"� jogador do "+i+"� time: ");
				double altura = sc.nextDouble();
				System.out.print("Informe o peso do "+j+"� jogador do "+i+"� time: ");
				double peso = sc.nextDouble();
				if(idade < 18) {
					qtdMenor18++;
				}
				somaIdade += idade;
				somaAltura += altura;
				if(peso > 80) {
				somaPeso += peso;
				}
			}
		}
		mediaIdade = somaIdade / 22;
		mediaAltura = somaAltura / 22;
		porcentagePeso = (somaPeso / 22)* 100;
		System.out.println("Quantidade de jogadores com idade menor que 18: "+ qtdMenor18
				+ "\nM�dia de idade: "+mediaIdade
				+ "\nM�dia de altura: "+mediaAltura
				+ "\nPorgentagem de jogadores com peso maior que 80Kg: "+porcentagePeso+"%");
		sc.close();
	}

}
