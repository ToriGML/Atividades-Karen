var link = "";

//------------------------------------------------------------------------

function gg(){
    var preview = document.querySelector('#imagem1');
    var file    = document.querySelector('input[type=file]').files[0];
    var reader  = new FileReader();
  
    reader.onloadend = function () {
      preview.src = reader.result;
      link = reader.result;
    }
    if (file) {
     reader.readAsDataURL(file);
    } else {
      preview.src = "";
    }
  }

function troca(){

  localStorage.setItem("imagemm", link);
  localStorage.setItem("name", nome.value);
  window.open("visualizar.html");

  const div3 = document.getElementById("icon");
  div3.href = link;


}
