
var linkImage = localStorage.getItem("imagemm");
 
const div = document.getElementById("IMG");
div.src = linkImage;

const div2 = document.getElementById("text");
div2.innerText = localStorage.getItem("name");

const div3 = document.getElementById("icon");
div3.href = linkImage;

function add(){
console.log("funcionou");
const prod = document.getElementById("root");
const produtos = JSON.stringify(localStorage.getItem("produtos"));
for(let i=0; i < produtos.length; i++){
    prod.innerHTML = `
    <div>
    <p>Nome: ${produtos[i].nome}</p>
    </div> 
    `;    
}
}