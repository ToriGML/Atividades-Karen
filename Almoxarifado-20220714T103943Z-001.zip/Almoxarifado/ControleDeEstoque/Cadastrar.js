const set = (produtos) => localStorage.setItem("produtos", JSON.stringify(produtos));
const get = () => JSON.parse(localStorage.getItem("produtos")) ?? [];
const create = (produto) => {
  const produtos = get();
  produtos.push(produto);
  set(produtos);
}

var linkImage = localStorage.getItem("imagemm");

const div = document.getElementById("IMG");
div.src = linkImage;

const div2 = document.getElementById("text");
div2.innerText = localStorage.getItem("name");

const div3 = document.getElementById("icon");
div3.href = linkImage;


function enviar() {
  console.log("ENVIAR");

    const produto = {

      nome: document.getElementById("nome").value,
      desc: document.getElementById("desc").value,
      quant: document.getElementById("quant").value,
      preco: document.getElementById("preco").value,
      medida: document.getElementById("medida").value,
      tipo: document.getElementById("tipo").value

    }

    create(produto);

    window.close("Cadastrar.html");
    window.open("visualizar.html");

  } 